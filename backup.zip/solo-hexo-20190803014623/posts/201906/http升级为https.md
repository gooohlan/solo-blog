title: http升级为https
date: '2019-06-05 14:46:03'
updated: '2019-06-05 14:46:42'
tags: [docker, 环境搭建, nginx, centos]
permalink: /articles/2019/06/05/1559717163020.html
---
![](https://img.hacpai.com/bing/20180322.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

## 前言
网上有很多将http升级为https的教材，在折腾了无数次后，我也成功将我的http升级为https，所以写一篇帖子记录一下，希望可以帮到大家。

## 前置条件

* 拥有自己的域名
* 一台服务器，并将域名解析到服务器上
* 一定的linux基础和docker基础，至少能跟着敲
* 本教程基于Centos7.*

### 使用docker安装nginx，并配置好相关配置文件，确保能够正常访问

![image.png](https://img.hacpai.com/file/2019/06/image-a608c8a4.png)

### <font color=red>特别提醒:</font>

* 启动的nginx需要监听443端口，因为443端口是https所需的端口
* 能够自由修改配置文件
* 最后单独放置一个文件用来存储ssl证书，比如：`-v /docker-data/nginx/ssl:/ssl/ #证书上传到服务器上的/docker-data/nginx/ssl目录下即可`
### 申请一个SSL证书
网上有很多可以免费申请的地方，我的证书是在[腾讯云](https://buy.cloud.tencent.com/ssl?fromSource=ssl)申请的，跟进相应提示正确下载即可。
![image.png](https://img.hacpai.com/file/2019/06/image-1dab87f3.png)
### 配置nginx文件
> 打开nginx的配置文件，根据实际情况(有可能是nginx文件下的nginx.conf，也有可能是conf.d下的default.conf)

```
server{
   #listen       80;  						# 需要同时打开https与htt时开启
    listen       443 ssl;
    server_name  www.jinjianh.com jinjianh.com;   # 换成你的域名
    ssl on;  								# 需要同时打开https与htt时注释掉
    ssl_certificate /ssl/1_www.jinjianh.com_bundle.crt;  # 换成你的证书对应地址
    ssl_certificate_key /ssl/2_www.jinjianh.com.key;      # 换成你的证书对应地址
    # 下面的部分不用改
    ssl_session_timeout 5m;
    ssl_protocols TLSv1 TLSv1.1 TLSv1.2;
    ssl_ciphers ECDHE-RSA-AES128-GCM-SHA256:HIGH:!aNULL:!MD5:!RC4:!DHE;
    ssl_prefer_server_ciphers on;
    # 换成你的项目地址
    location / {
        root   /usr/share/nginx/html;
        index  index.html index.htm;
    }
    # 这里是一些其它配置项
}
```

> 如果需要只能访问https的话，需要将`listen 80`注释掉和`ssl on`打开，并新增如下配置

```
server{
  listen 80;
  server_name jinjianh.com www.jinjianh.com;
  rewrite ^(.*) https://$host$1 permanent;
}
```

> 保持配置，重启nginx，使用docker启动的nginx一开始没有监听443端口的话会失败，重新打开一个监听443端口的nginx容器
> 成功效果如下
![image.png](https://img.hacpai.com/file/2019/06/image-08d797bc.png)
