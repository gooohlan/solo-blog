title: 【go语言圣经】练习答案 -- 第四章(更新中)
date: '2019-06-12 17:21:44'
updated: '2019-06-12 18:20:46'
tags: [golang, 教程, 学习]
permalink: /articles/2019/06/12/1560331304695.html
---
### 练习 4.1： 编写一个函数，计算两个SHA256哈希码中不同bit的数目。（参考2.6.2节的PopCount函数。)
> 解题思路:

* 先将字符串转换为SHA256
* 循环数组，查看哈希码中bit是否相同，不同则记录。
```
func Sha256(str1 string, str2 string) int {
    a := sha256.Sum256([]byte(str1))
    b := sha256.Sum256([]byte(str2))
    num := 0
    // 循环字节数组
    for i := 0; i < len(a); i++ {
        // 循环查看8个字节判断是否相同
        for i := uint(0); i < 8; i++ {
            if a[i]>>(i*8) != b[i]>>(i*8) {
                num++
            }
        }
    }
    return num
}
```

### 练习 4.2： 编写一个程序，默认情况下打印标准输入的SHA256编码，并支持通过命令行flag定制，输出SHA384或SHA512哈希算法。

> 解题思路：

* 监听命令行输入
* 判断命令行给的哈希算法，输出对应哈希码
```
// 命令行标志, -s 需要加密的字符串  -h 使用的哈希算法

var Str=flag.String("s","X","请输入字符串")

var Sha=flag.String("h","sha256","请输入哈希算法")
func main() {
    flag.Parse()
    OutputHash(strings.ToUpper(*Sha),strings.ToUpper(*Str))
}

func OutputHash(flag, str string) {
    // 使用switch,默认输出SHA256
    switch flag {
    case "SHA384":
        fmt.Printf("%x\n", sha512.Sum384([]byte(str)))
        return
    case "SHA512":
        fmt.Printf("%x\n", sha512.Sum512([]byte(str)))
        return
    default:
        fmt.Printf("%x\n", sha256.Sum256([]byte(str)))
        return
    }
}
```

### 返回目录

[【go语言圣经】练习答案–目录篇](https://www.jinjianh.com/articles/2019/06/12/1560321174820.html)











