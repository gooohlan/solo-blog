title: 日刷leetcode--简单版系列（目录篇）
date: '2019-07-29 17:19:31'
updated: '2019-09-14 15:20:09'
tags: [golang, leetcode, 算法]
permalink: /leetcode.html
---
### 前言
谨以此贴记录我刷题的过程，那么我为啥要刷题呢

1. 熟悉各互联网公司的算法题目，为找工作做准备。  
2. 复习以前学过的编程语言，LeetCode支持几乎所有主流编程语言，大家可以用不同语言来做题。  
3. 熟悉常见的算法和数据结构，LeetCode提供了交流平台，一些大神会将自己的解法贴出来共享，有些巧妙的解法实在令人叫绝，虽然几乎都是英文，但上面的国人也特别多（中文拼音名字>_<）。  
4. 学习别人的编程思维，加快编程的速度，避免常见的BUG。

以上内容摘抄自网络，纯属瞎说，真是的原因是：

* 因为上班工作做完后，不敢明目张胆的摸鱼
* 下班无聊不想打游戏
* 算法真的很弱
* ......

时过境迁，上次打开leetcode的时候还没有中文版，而现在已经有了--[力扣](https://leetcode-cn.com/)。
由于篇幅的问题，我觉得5题一篇，话不多说。

### 目录：

* [日刷leetcode--简单版系列（一）](https://www.jinjianh.com/leetcode1.html)
* [日刷leetcode--简单版系列（二）](https://www.jinjianh.com/leetcode2.html)
* [日刷leetcode--简单版系列（三）](https://www.jinjianh.com/leetcode3.html)
* [日刷leetcode--简单版系列（四）](https://www.jinjianh.com/leetcode4.html)
* [日刷leetcode--简单版系列（五）](https://www.jinjianh.com/leetcode5.html)
