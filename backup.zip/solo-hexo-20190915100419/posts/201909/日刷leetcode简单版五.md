title: 日刷leetcode--简单版（五）
date: '2019-09-14 15:19:40'
updated: '2019-09-14 15:20:54'
tags: [待分类]
permalink: /leetcode5.html
---
![](https://img.hacpai.com/bing/20180327.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

### 返回总目录

[日刷leetcode–简单版](https://www.jinjianh.com/leetcode.html)

---

### 119. 杨辉三角 II
#### 题目描述
![image.png](https://img.hacpai.com/file/2019/09/image-991e2526.png)
#### 解题思路
* 此题与118类似，直接冲118中返回最后一个数组即可，但是要优化到O(k)就显得不是那么容易了
* 公式:![image.png](https://img.hacpai.com/file/2019/09/image-570d44cb.png)
* 简单的来说就是前面的数乘以一个分数,这个分数从左到右分别为n/1, (n-1)/2, ..., 2/(n-1), 1/n，比如第3行就是分别乘以3/1，2/2，1/3
* 这里要注意的是[1]是第0行，而非第一行
#### 示例代码
```go
func getRow(rowIndex int) []int {
    arr := make([]int,rowIndex+1)
    if rowIndex == 0{
        return arr
    }
    arr[0] = 1
    for i:= 1; i <= rowIndex; i++ {
        arr[i] = arr[i-1] * (rowIndex-i+1)/i
    }
    return arr
}
```
#### 运行结果
> 执行用时 :0 ms, 在所有 Go 提交中击败了100.00%的用户
> 内存消耗 :2 MB, 在所有 Go 提交中击败了90.24%的用户


