title: Docker导出mysql数据
date: '2019-06-11 23:43:54'
updated: '2019-06-12 10:46:32'
tags: [mysql, docker, solo]
permalink: /articles/2019/06/11/1560267833958.html
---
![](https://img.hacpai.com/bing/20181008.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

# 前言
&emsp;&emsp;前几天无意中在社区看到一个帖子（[记一次清空数据仓库的过程](https://hacpai.com/article/1553941852324)），讲的是自己无意中删库的经历。如文中所讲，大多时候删库这件事我们只是耳闻，并没有遇到过，可要是万一呢，到时候恐怕是追悔莫及，而且mysql也没有oracle的恢复机制，所以备份就成了一个非常有必要的操作。

&emsp;&emsp;由于没有相关操作经验，所以从零开始讲如何数据，毕竟我还是比较珍惜我的小博客的。

# 具体操作
&emsp;&emsp;以前也导出过sql文件，但是都是直接用Navicat导出就完事了，但是这次我想实现的是自动备份，最好写成脚本的方式。

&emsp;&emsp;基本思路：使用命令将数据库数据从docker容器中导出来，以时间戳命名。最多保持7天，过期文件自动删除。
### 导出mysql数据
&emsp;&emsp;mysql 导出数据的命令还是蛮简单的：`mysqldump -u 用户名 -p 数据库名 > 导出的文件名`，但这是linux里面执行的，我们的放在docker里面，所以要先进入容器，然后执行上述命令。然后你就会惊讶的发现，导出的文件在你的容器里面，然后你再从容器里面copy到你的主机上。

&emsp;&emsp;上述方法是可行的，但是过于麻烦，有没有一步到位的呢？很显然是有的，命令是这个样子的：`docker exec -it [docker容器名称/ID] mysqldump -u[数据库用户名] -p[数据库密码] [数据库名称] > [导出表格路径]`，比如我的`docker exec -it mysql mysqldump -uroot -p123456 solo > /var/www/solo.sql`。没有报错的话，导出的数据库文件就会到你指定的目录下了。

### 写成脚本方式运行

&emsp;&emsp;博主是不会写Shell脚本的，所以现学了下，参考[Shell脚本编程30分钟入门](https://github.com/qinjx/30min_guides/blob/master/shell.md)，到你的目录，创建.sh文件，写入如下命令。
```bash
#!/bin/sh
# 进入你要保持数据的文件
cd /var/www/html/solo/sqlData
# 导出今日的sql
docker exec -it mysql mysqldump -uroot -p123456 solo >`date +%Y%m%d%H%M%S`.sql
# 删除7天前的sql(+号后面跟天数,N天前,find后指定目录)
find . -mtime +7 -type f | xargs rm -rf
```

> 这里有一个小坑，命令行执行shell时回报错，提示权限不足，网上说需要把shell文件权限设置为777，但是我们的shell文件只需要读取和执行，所以755就可以了。

&emsp;&emsp;在当前目录下执行./文件名.sh就可以执行了，效果正常后进入下一步。

&emsp;&emsp;接下来就是定时运行，这部分比较简单，使用crontab，不知道怎么用的，[点击这里](https://hacpai.com/tag/crontab)。

&emsp;&emsp;我们先测试一下，让它一分钟备份一次。

```
crontab -e

*/1 * * * * /var/www/html/sh/BackupSoloSql.sh  > /dev/null 2>&1 &
```
&emsp;&emsp;如下图所示，每分钟都备份了一次，证明我的shell命令没错，定时任务也没错，重修修改定时任务的执行时间即可。

![image.png](https://img.hacpai.com/file/2019/06/image-ea3be1f9.png)

&emsp;&emsp;我改成了每天凌晨0点0分执行。

```
crontab -e

0 0 * * * /var/www/html/sh/BackupSoloSql.sh  > /dev/null 2>&1 &
```
# 后记

&emsp;&emsp;这种导出是导出到当前主机下的，指不定哪天出点啥意外，导致主机丢失，比如在根目录执行了`rm -rf /*`。所有还是需要你不定时的将我们已经备份好的文件下载到本地。

&emsp;&emsp;这里我不讲如何导入，如果你的系统出了问题，数据库丢失需要导入的话，直接把目录中最新的sql文件下载下来，然后在本地使用Navicat连接数据库，拖进去就完事了。