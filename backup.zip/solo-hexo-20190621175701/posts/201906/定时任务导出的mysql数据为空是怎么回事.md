title: 定时任务导出的 mysql 数据为空是怎么回事
date: '2019-06-16 20:49:12'
updated: '2019-06-16 20:49:12'
tags: [待分类, Q&A]
permalink: /articles/2019/06/16/1560689303886.html
---
![null](https://img.hacpai.com/file/2019/06/image-bd6634f2.png?imageView2/2/w/768/interlace/1/format/webp)
![null](https://img.hacpai.com/file/2019/06/image-ae99d83c.png?imageView2/2/w/768/interlace/1/format/webp)

直接执行`docker exec -it mysql /usr/bin/mysqldump -uroot -p123123 solo >`date +%Y%m%d%H%M%S`.sql
`就可以正常导出sql