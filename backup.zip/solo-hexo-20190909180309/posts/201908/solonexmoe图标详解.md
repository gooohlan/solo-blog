title: solo-nexmoe 图标详解
date: '2019-08-23 16:26:25'
updated: '2019-08-30 23:32:20'
tags: [Solo, solo-nexmoe]
permalink: /articles/2019/08/23/1566548785550.html
---
## 前言
本帖记录官方solo-nexmoe内所对应字体图标值
* `solo-home` <i class="iconfont solo-home"></i>

* `solo-list` <i class="iconfont solo-list"></i>

* `solo-tags` <i class="iconfont solo-tags"></i>

* `solo-tag` <i class="iconfont solo-tag"></i>

* `solo-github` <i class="iconfont solo-github"></i>

* `solo-about` <i class=" iconfont solo-about"></i>

* `solo-search` <i class=" iconfont solo-search"></i>

* `solo-rss` <i class=" iconfont solo-rss"></i>

* `solo-calendarl` <i class=" iconfont solo-calendarl"></i>

* `solo-category` <i class=" iconfont solo-category"></i>

* `solo-left` <i class=" iconfont solo-left"></i>

* `solo-right` <i class=" iconfont solo-right"></i>

* `solo-browse` <i class=" iconfont solo-browse"></i>

* `solo-heat` <i class=" iconfont solo-heat"></i>

* `solo-about2` <i class=" iconfont solo-about2"></i>

* `solo-top` <i class=" iconfont solo-top"></i>

* `solo-login` <i class=" iconfont solo-login"></i>

* `solo-logout` <i class=" iconfont solo-logout"></i>

* `solo-spin` <i class=" iconfont solo-spin"></i>

* `solo-comment` <i class=" iconfont solo-comment"></i>

* `solo-` <i class=" iconfont solo-"></i>  自定义导航不设置图标时显示

