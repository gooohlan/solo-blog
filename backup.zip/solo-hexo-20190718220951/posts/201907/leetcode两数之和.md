title: leetcode--两数之和
date: '2019-07-16 15:17:53'
updated: '2019-07-16 15:20:19'
tags: [leetcode, golang]
permalink: /articles/2019/07/16/1563261472913.html
---
![LeetCodeSharing.png](https://img.hacpai.com/file/2019/07/LeetCodeSharing-95ea6973.png)

### 1.两数之后
#### 题目描述:
> 给定一个整数数组 nums 和一个目标值 target，请你在该数组中找出和为目标值的那 两个 整数，并返回他们的数组下标。
>你可以假设每种输入只会对应一个答案。但是，你不能重复利用这个数组中同样的元素。

#### 示例:

```
给定 nums = [2, 7, 11, 15], target = 9
因为 nums[0] + nums[1] = 2 + 7 = 9
所以返回 [0, 1]
```
##### 解题思路1：暴力法，双循环相加结果等于target就返回
```
func twoSum(nums []int, target int) []int {
    for i := 0; i < len(nums); i++ {
        for j := i + 1; j < len(nums); j++ {
            if nums[i] + nums[j] ==target {
                return []int{i,j}
            }
        }
    }
    return nil
}
```
> 执行用时 :56 ms, 在所有 Go 提交中击败了32.33%的用户
> 内存消耗 :3 MB, 在所有 Go 提交中击败了78.76%的用户

##### 解题思路2：遍历一次，求当前值的下标是否存在哈希表中，存在就返回，不存在就将当前值与下标存入哈希表
```
func twoSum(nums []int, target int) []int {
    maps := make(map[int]int)

    for k, v := range nums {
        difference := target - v
        if _, ok := maps[difference]; ok {  // 判断是否存在指定k的值
            return []int{maps[difference], k}
        }
        maps[v] = k // 将值作为key存储到map中
        }
    return nil
}
```
> 执行用时 :4 ms, 在所有 Go 提交中击败了89.93%的用户
> 内存消耗 :3.8 MB, 在所有 Go 提交中击败了30.06%的用户