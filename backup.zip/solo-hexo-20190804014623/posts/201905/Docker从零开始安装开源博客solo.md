title: Docker从零开始安装开源博客solo
date: '2019-05-31 17:33:04'
updated: '2019-06-03 15:19:04'
tags: [docker, centos, solo, 环境搭建]
permalink: /first.html
---
![1JAJ910fg52ODIRZjHXASBQ.png](https://img.hacpai.com/file/2019/05/1JAJ910fg52ODIRZjHXASBQ-4b8b2a79.png)




## 1.首先你得有自己的服务器，没有就去买一台吧。

## 2.在你的服务器上安装一个Liunx系统，Centos或者Ubuntu（我使用的是Centos7.*）

## 3.安装docker(使用yum，一步到位)
```
// 安装docker
yum -y install docker-ce

// 启动 Docker 后台服务
systemctl start docker
```

## 4.安装并允许Mysql(MySQL版本需5.7+)
```
// 使用docker下载mysql 8.0
docker pull mysql:8.0

// * 运行mysql
// * XXXX处换成你的mysql密码
docker run --name mysql -p 3306:3306 -e MYSQL_ROOT_PASSWORD=XXXX -d mysql8.0

// * docker安装的mysql默认允许远程连接，可以使用Navicat等软件连接数据库
// * 如果不能远程连接，则进入容器mysql进行修改(方法自行Google)
// * 创建solo使用的数据库（使用客户端连接忽略命令行）
// * 进入容器mysql
docker exec -it mysql bash

// 进入数据库
mysql -uroot -pXXX

// 创建数据库(数据库名:solo;字符集utf8mb4;排序规则utf8mb4_general_ci)
create database solo DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;

// 退出mysql
exit;

// 退出容器
exit
```

## 5.下载solo,并启动solo
```
// 下载solo
docker pull b3log/solo

// * 启动solo
// * JDBC_PASSWORD="你的数据库密码"
// * listen_port=80 监听你想监听的端口
// * server_scheme=http/https https好像有点麻烦，自己鼓捣吧
// * server_host=XXX IP地址或域名，使用域名时尽量写全，如www.jinjianh.com。
docker run --detach --name solo \
--network=host --env RUNTIME_DB="MYSQL" \
--env JDBC_USERNAME="root" \
--env JDBC_PASSWORD="XXX"  \
--env JDBC_DRIVER="com.mysql.cj.jdbc.Driver" \
--env JDBC_URL="jdbc:mysql://127.0.0.1:3306/solo?useUnicode=yes&characterEncoding=UTF-8&useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC" \
b3log/solo --listen_port=80 --server_scheme=http --server_host=XXXX
```
# over
访问你的域名或者ip就能进入你的solo了

![1c8c8400211e7de628088f9e1980aff74247c9c2.png1320w590h.webp](https://img.hacpai.com/file/2019/05/1c8c8400211e7de628088f9e1980aff74247c9c2.png1320w590h-e2243aec.webp)

使用github账号登录即可

最后的最后:solo很好看，看板娘很萌

github solo地址: [https://github.com/b3log/solo](https://)
