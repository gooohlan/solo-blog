title: nginx反向代理配置solo，并实现https访问
date: '2019-06-05 15:30:10'
updated: '2019-06-05 15:30:10'
tags: [solo, docker, nginx, 环境搭建]
permalink: /articles/2019/06/05/1559719810531.html
---
## 1.前置条件
* [什么是solo?](https://github.com/b3log/solo)
* [安装solo](https://www.jinjianh.com/first.html)

使用官方默认配置安装solo后，默认占用了80端口，总感觉这样不是特别好，而且没有灵魂。
### 基本思路

* 运行时可指定端口，默认solo绑定8080端口
* 使用nginx将80反向代理到8080端口

> solo启动时参数 --listen_port=8080

> 修改nginx配置
```
location / {
	# 换成你的域名
        proxy_pass http://www.jinjianh.com:8080;
    }
```
重启nginx，删掉现在的solo容器，重新启动一个solo容器或者更新容器参数。

### 出现的问题

我们想要的功能就实现了，在浏览器上访问[www.jinjianh.com](https://www.jinjianh.com)即可正确访问博客。但是博客内所有的域名都指向的是8080端口，比如我们想查看“Docker从零开始安装开源博客solo”，应该访问的域名是`www.jinjianh.com/first.html`，实际上访问的确是`www.jinjianh.com：8080/first.html`。

> 解决办法

启动solo时，添加参数`--server_port=` 值留空，或者设置为80（80好像不行，猜测是因为nginx占用了80端口），重新启动一个solo容器，或者更新参数。

### 最后
至此，就可以直接通过访问80端口的域名，去访问8080端口所在的域名。

如果你用nginx配置了https，可以通过修改参数`--server_scheme=https`即可，如何配置https可查看我的另外一篇博客 [http升级为https ](https://www.jinjianh.com/articles/2019/06/05/1559717163020.html)。


