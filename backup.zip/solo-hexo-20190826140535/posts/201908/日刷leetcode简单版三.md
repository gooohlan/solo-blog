title: 日刷leetcode--简单版（三）
date: '2019-08-09 11:58:53'
updated: '2019-08-26 13:49:23'
tags: [算法, leetcode, golang]
permalink: /leetcode3.html
---
### 返回总目录

[日刷leetcode–简单版](https://www.jinjianh.com/leetcode.html)

---

### 58. 最后一个单词的长度
#### 题目描述
![image.png](https://img.hacpai.com/file/2019/08/image-45f2c7e9.png)
#### 解题思路
* 定义一个变量统计，从前往后遍历，遇到空格归零就可以了，注意处理最后几个个字符全为空格的情况
* 定义一个变量统计，从后往前便利，虽然时间复杂度同为O(n)，但是第二个明显快很多
#### 示例代码
```
func lengthOfLastWord(s string) int {
        var count int
                for i:= len(s)-1; i >= 0; i-- {
                        if s[i] == 32{
                                if count == 0 {
                                        continue
                                }else{
                                        break
                                }
                        }
                        count ++
                }
        return count
}
```
##### 运行结果
> 执行用时 :0 ms, 在所有 Go 提交中击败了100.00%的用户
> 内存消耗 :2.2 MB, 在所有 Go 提交中击败了39.13%的用户

### 66.加一
#### 题目描述
![image.png](https://img.hacpai.com/file/2019/08/image-1081bedf.png)
##### 解题思路
* 从后面往前面循环，最后以一位加1即可，处理好末尾`9`与`999`
```
func plusOne(digits []int) []int {
        c := 1 // 定义一个变量用来进位，进位归零则程序结束
        for i := len(digits) - 1; i >= 0; i-- {
                digits[i] += c
                c--
                if digits[i] == 10 {
                        digits[i] = 0
                        c = 1
                }
                if c == 0 {
                        return digits
                }
        }
        if c != 0 { // 循环完后依旧存在进位则表示遇到了999
                digits = append([]int{1}, digits...)
        }
        return digits
}
```
#### 运行结果
> 执行用时 :0 ms, 在所有 Go 提交中击败了100.00%的用户
> 内存消耗 :2.2 MB, 在所有 Go 提交中击败了30.57%的用户

### 67.二进制求和

#### 题目描述

![image.png](https://img.hacpai.com/file/2019/08/image-21de0dac.png)

#### 解题思路

* 判断两个字符串的大小，保证a为较长的一个
* 从后往前循环相加，先循环较短的字符串，再循环长字符串剩余的，定义一个变量记录是否需要进位，两个字符串相加是需要加上进位的值
* 最后判断进位值是否为0，不为0则在相加后字符串最前面一位加1

#### 示例代码

```
func addBinary(a string, b string) string {
	la, lb := len(a), len(b)
	if la < lb {
		la, lb = lb, la
		a, b = b, a
	}
	var carry, s byte
	str := make([]byte, la+1)
	for lb > 0 {
		la--
		lb--
		s = byte(a[la]-'0') + byte(b[lb]-'0') + carry
		carry = s / 2
		s = s % 2
		str[la+1] = byte(s + '0')
	}
	for la > 0 {
		la--
		s = byte(a[la]-'0') + carry
		carry = s / 2
		s = s % 2
		str[la+1] = byte(s + '0')
	}
	if carry == 1 {
		str[la] = carry + '0'
	} else {
		str = str[la+1:]
	}
	return string(str[la:])
}
```

#### 运行结果

> 执行用时 :0 ms, 在所有 Go 提交中击败了100.00%的用户> 内存消耗 :2.3 MB, 在所有 Go 提交中击败了68.18%的用户
