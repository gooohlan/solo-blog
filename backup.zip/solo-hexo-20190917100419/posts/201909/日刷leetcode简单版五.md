title: 日刷leetcode--简单版（五）
date: '2019-09-14 15:19:40'
updated: '2019-09-16 22:20:58'
tags: [待分类, leetcode, 算法]
permalink: /leetcode5.html
---
![](https://img.hacpai.com/bing/20180327.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

### 返回总目录

[日刷leetcode–简单版](https://www.jinjianh.com/leetcode.html)

---

### 119. 杨辉三角 II
#### 题目描述
![image.png](https://img.hacpai.com/file/2019/09/image-991e2526.png)
#### 解题思路
* 此题与118类似，直接冲118中返回最后一个数组即可，但是要优化到O(k)就显得不是那么容易了
* 公式:![image.png](https://img.hacpai.com/file/2019/09/image-570d44cb.png)
* 简单的来说就是前面的数乘以一个分数,这个分数从左到右分别为n/1, (n-1)/2, ..., 2/(n-1), 1/n，比如第3行就是分别乘以3/1，2/2，1/3
* 这里要注意的是[1]是第0行，而非第一行
#### 示例代码
```go
func getRow(rowIndex int) []int {
    arr := make([]int,rowIndex+1)
    if rowIndex == 0{
        return arr
    }
    arr[0] = 1
    for i:= 1; i <= rowIndex; i++ {
        arr[i] = arr[i-1] * (rowIndex-i+1)/i
    }
    return arr
}
```
#### 运行结果
> 执行用时 :0 ms, 在所有 Go 提交中击败了100.00%的用户
> 内存消耗 :2 MB, 在所有 Go 提交中击败了90.24%的用户


### 121. 买卖股票的最佳时机

#### 题目描述
![image.png](https://img.hacpai.com/file/2019/09/image-4ef0e447.png)
#### 解题思路1
* 双循环，对于每组 i 和 j（其中 j > i）我们需要找出 max(prices[j] - prices[i])
#### 示例代码（无）

#### 解题思路二
* 循环一次，分别记录最小买入与最大利润即可
#### 示例代码
```
func maxProfit(prices []int) int {
    maxPrices, min := 0, math.MaxUint32
    for i := 0; i < len(prices); i++ {
        if prices[i] < min {
            min = prices[i] // 最小买入
        }
        if prices[i] - min > maxPrices {
            maxPrices = prices[i] - min  // 最大利润
        }
    }
    return maxPrices
}
```
#### 运行结果
> 执行用时 :4 ms, 在所有 Go 提交中击败了98.17%的用户
> 内存消耗 :3.1 MB, 在所有 Go 提交中击败了80.77%的用户
