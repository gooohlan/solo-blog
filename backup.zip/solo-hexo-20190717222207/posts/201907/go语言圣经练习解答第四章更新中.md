title: go 语言圣经练习解答 -- 第四章 (更新中)
date: '2019-07-16 15:54:22'
updated: '2019-07-16 17:47:41'
tags: [golang, 学习, 教程]
permalink: /articles/2019/06/12/1560331304695.html
---
## go语言圣经(The Go Programming Language)第四章练习题答案

#### 练习 4.1： 编写一个函数，计算两个SHA256哈希码中不同bit的数目。（参考2.6.2节的 PopCount函数。)

> 解题思路

* 循环字节数组
* 循环字节bit，对比是否相同
<iframe style="border:1px solid" src="https://wide.b3log.org/playground/1de1b0989661e96a455fb5f24c9752d2.go" width="99%" height="600"></iframe>

#### 练习 4.2： 编写一个程序，默认打印标准输入的以SHA256哈希码，也可以通过命令行标准参 数选择SHA384或SHA512哈希算法。
> 解题思路

* 获取命令行输入的参数
* 通过命令行参数返回值
<iframe style="border:1px solid" src="https://wide.b3log.org/playground/8a883544635b919cd2f822312adb81cf.go" width="99%" height="600"></iframe>
> 实际效果

![image.png](https://img.hacpai.com/file/2019/07/image-0d9ee8d7.png)

#### 练习 4.3: 重写reverse函数,使用数组指针代替slice。
> 解题思路(无)

<iframe style="border:1px solid" src="https://wide.b3log.org/playground/12a10f74a7fc189d271d8c6aa1de3d95.go" width="99%" height="600"></iframe>
